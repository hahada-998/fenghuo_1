[ActiveSupport TRCE]
; Setup Analysis
Fmax_0 = - (-);
Fmax_1 = - (-);
Fmax_2 = 82.440 MHz (50.000 MHz);
Fmax_3 = 39.111 MHz (25.000 MHz);
Failed = 0 (Total 4);
Clock_ports = 9;
Clock_nets = 15;
; Hold Analysis
Fmax_0 = - (-);
Fmax_1 = - (-);
Fmax_2 = 0.304 ns (0.000 ns);
Fmax_3 = 0.304 ns (0.000 ns);
Failed = 0 (Total 4);
Clock_ports = 9;
Clock_nets = 15;
